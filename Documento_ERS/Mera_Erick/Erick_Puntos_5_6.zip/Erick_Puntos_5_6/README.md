# Puntos 5 y 6 - Modelo de datos + Modelo funcional

Este ZIP contiene el aporte separado para subirlo a GitHub como evidencia individual o por carpeta.

## Integrante sugerido
- Mera Arias Erick Jhair

## Secciones incluidas
- Modelo de datos: ER y clases UML
- Modelo funcional: DFD y actividades UML

## Archivos incluidos
- `Erick_Puntos_5_6.tex`: fragmento LaTeX correspondiente a estos puntos, extraído del documento principal.
- `Erick_Puntos_5_6.pdf`: páginas del PDF final que corresponden a estos puntos.
- Carpeta `fuentes/`: archivos fuente relacionados, cuando existen en `/mnt/data`.

## Rango extraído
- Líneas del `.tex`: 647-1316
- Páginas del PDF: 28-43

Recomendación: subir este ZIP o, mejor, subir la carpeta descomprimida al repositorio para que se vea el contenido del aporte.
