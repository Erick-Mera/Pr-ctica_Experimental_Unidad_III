# Ariel Puntos 9 10 Apendice A

## Integrante asignado
- Castro Bajaña Ariel Omar

## Contenido del paquete
- `Puntos_9_10/`: Puntos 9 y 10 - Conclusiones + Referencias bibliográficas
- `Apendice_A/`: Apéndice A - Tabla completa de atributos de RF y RNF

Cada carpeta contiene un PDF, un fragmento LaTeX, un README específico y una carpeta `fuentes` cuando corresponde.
