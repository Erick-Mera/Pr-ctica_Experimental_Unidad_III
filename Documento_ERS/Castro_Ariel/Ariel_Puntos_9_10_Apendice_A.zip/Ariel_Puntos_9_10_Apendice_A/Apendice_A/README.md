# Apéndice A - Tabla completa de atributos de RF y RNF

Este paquete contiene el aporte separado para subirlo a GitHub como evidencia individual o por carpeta.

## Integrante asignado
- Castro Bajaña Ariel Omar

## Secciones incluidas
- Apéndice A: Tabla completa de atributos de RF y RNF

## Archivos incluidos
- `Apendice_A.tex`: fragmento LaTeX correspondiente a esta parte, extraído del documento principal.
- `Apendice_A.pdf`: páginas del PDF final que corresponden a esta parte.
- Carpeta `fuentes/`: archivos fuente relacionados, cuando existen en `/mnt/data`.

## Rango extraído
- Líneas del `.tex`: 2009-2127
- Páginas del PDF: 59-62

## Nota de paginación
La primera página incluye el cierre de referencias porque el Apéndice A inicia al final de esa página en el PDF original.

Recomendación: subir este paquete o la carpeta descomprimida al repositorio para que se vea el contenido del aporte.
