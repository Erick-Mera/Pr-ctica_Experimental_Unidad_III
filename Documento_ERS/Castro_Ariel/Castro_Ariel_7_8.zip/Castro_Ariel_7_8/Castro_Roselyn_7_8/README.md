# Puntos 7 y 8 - Modelo de comportamiento + Matriz de trazabilidad y coherencia entre modelos

Este ZIP contiene el aporte separado para subirlo a GitHub como evidencia individual o por carpeta.

## Integrante sugerido
- Sanchez Centeno Roselyn Andreina

## Secciones incluidas
- Modelo de comportamiento: estados y secuencia
- Matriz de trazabilidad y coherencia entre modelos

## Archivos incluidos
- `Roselyn_Puntos_7_8.tex`: fragmento LaTeX correspondiente a estos puntos, extraído del documento principal.
- `Roselyn_Puntos_7_8.pdf`: páginas del PDF final que corresponden a estos puntos.
- Carpeta `fuentes/`: archivos fuente relacionados, cuando existen en `/mnt/data`.

## Rango extraído
- Líneas del `.tex`: 1317-1939
- Páginas del PDF: 44-56

Recomendación: subir este ZIP o, mejor, subir la carpeta descomprimida al repositorio para que se vea el contenido del aporte.
